<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Flights - Go Travel & Tourism Ltd</title>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href="stylecss.css" rel='stylesheet' type='text/css'/>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> 
    addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); 
    function hideURLbar(){ window.scrollTo(0,1); } 
</script>
<script src="js/jquery.min.js"></script>
</head>

<body>
<?php include('function.php'); ?>
<?php include('top.php'); ?>
<br><br><br>
<div style="height:50px"></div>
<div style="width:1000px; margin:auto">

<div style="width:200px; float:left">
<table cellpadding="0" cellspacing="0" width="1000px">
<tr><td style="font-size:30px; color:#09F"><b>Category</b></td></tr>
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database_name"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create the `flight` table
$createTableSQL = "
CREATE TABLE IF NOT EXISTS `flight` (
  `Flight_id` INT NOT NULL AUTO_INCREMENT,
  `Packid` INT NOT NULL,
  `Flight_number` VARCHAR(100) NOT NULL,
  `Departure_date` DATE NOT NULL,
  `Arrival_date` DATE NOT NULL,
  `Departure_location` VARCHAR(255) NOT NULL,
  `Arrival_location` VARCHAR(255) NOT NULL,
  `Available_seats` INT NOT NULL,
  PRIMARY KEY (`Flight_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
";
$conn->query($createTableSQL);

// Insert flight records
$insertSQL = "
INSERT INTO `flight` (`Packid`, `Flight_number`, `Departure_date`, `Arrival_date`, `Departure_location`, `Arrival_location`, `Available_seats`)
VALUES 
(1, 'AA101', '2024-12-15', '2024-12-15', 'JFK Airport', 'LAX Airport', 180),
(2, 'DL202', '2024-12-16', '2024-12-16', 'ORD Airport', 'SFO Airport', 150),
(3, 'UA303', '2024-12-17', '2024-12-17', 'LHR Airport', 'DXB Airport', 200),
(4, 'AF404', '2024-12-18', '2024-12-18', 'CDG Airport', 'ICN Airport', 220),
(5, 'LH505', '2024-12-19', '2024-12-19', 'FRA Airport', 'SYD Airport', 170),
(6, 'BA606', '2024-12-20', '2024-12-20', 'LHR Airport', 'ORD Airport', 140),
(7, 'QF707', '2024-12-21', '2024-12-21', 'SYD Airport', 'JFK Airport', 160),
(8, 'EK808', '2024-12-22', '2024-12-22', 'DXB Airport', 'SFO Airport', 180),
(9, 'AI909', '2024-12-23', '2024-12-23', 'DEL Airport', 'LHR Airport', 200),
(10, 'CZ1010', '2024-12-24', '2024-12-24', 'PEK Airport', 'CDG Airport', 150)
ON DUPLICATE KEY UPDATE Flight_number=VALUES(Flight_number);
";
$conn->query($insertSQL);

// Fetch flight categories
$s = "SELECT * FROM category";
$result = $conn->query($s);

while ($data = $result->fetch_assoc()) {
    echo "<tr><td style='padding:5px;'><b><a href='subcat.php?catid={$data['id']}'>{$data['name']}</a></b></td></tr>";
}
?>
</table>
</div>

<div style="width:500px; float:left">
<table cellpadding="10px" cellspacing="0" width="1000px">
<tr><td class="headingText">Available Flights</td></tr>
<tr><td>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tr>
    <th>Flight ID</th>
    <th>Package ID</th>
    <th>Flight Number</th>
    <th>Departure Date</th>
    <th>Arrival Date</th>
    <th>Departure Location</th>
    <th>Arrival Location</th>
    <th>Seats Available</th>
</tr>
<?php
$query = "SELECT * FROM `flight`";
$flights = $conn->query($query);

while ($flight = $flights->fetch_assoc()) {
    echo "<tr>
            <td>{$flight['Flight_id']}</td>
            <td>{$flight['Packid']}</td>
            <td>{$flight['Flight_number']}</td>
            <td>{$flight['Departure_date']}</td>
            <td>{$flight['Arrival_date']}</td>
            <td>{$flight['Departure_location']}</td>
            <td>{$flight['Arrival_location']}</td>
            <td>{$flight['Available_seats']}</td>
          </tr>";
}
$conn->close();
?>
</table>
</td></tr>
</table>
</div>

<div style="clear:both"></div>

<?php include('bottom.php'); ?>
</body>
</html>
